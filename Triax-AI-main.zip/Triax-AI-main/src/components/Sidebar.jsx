import React from 'react'

const Sidebar = () => {
  return (
    <div className="w-16 bg-gray-800 text-white flex flex-col items-center py-4 space-y-4">
      {/* Empty sidebar - icons removed */}
    </div>
  )
}

export default Sidebar
